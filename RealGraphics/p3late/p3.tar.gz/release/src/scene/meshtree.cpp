//
//  MeshTree.cpp
//  p4
//
//  Created by Nathan Dobson on 11/11/14.
//  Copyright (c) 2014 Nathan Dobson. All rights reserved.
//  A data structure for fast mesh/ray intersection test

#include "scene/meshtree.hpp"

#define MIN_REFINE_SIZE 2
#define MIN_REFINE_RATIO 2.0
namespace _462 {


} //namespace _462