/**
 * @file math.cpp
 * @brief General math function definitions.
 *
 * @author Eric Butler (edbutler)
 */

#include "math/math.hpp"

void theLinkerWantsSymbolsSoNowItHasOne(){

}
