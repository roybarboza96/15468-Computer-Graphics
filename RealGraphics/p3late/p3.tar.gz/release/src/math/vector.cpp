/**
 * @file vector.cpp
 * @brief Vector classes.
 *
 * @author Eric Butler (edbutler)
 */

#include "math/vector.hpp"

namespace _462 {

void anotherSymbolForTheLinker();

} /* _462 */

