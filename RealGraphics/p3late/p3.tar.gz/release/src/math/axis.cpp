//
//  axis.cpp
//  Photon Mapper
//
//  Created by Nathan A. Dobson on 2/3/15.
//  Copyright (c) 2015 CMU 15462. All rights reserved.
//

#include "axis.hpp"

